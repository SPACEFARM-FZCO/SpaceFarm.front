import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _094dafae = () => interopDefault(import('../pages/climateandzone.vue' /* webpackChunkName: "pages/climateandzone" */))
const _2de6ef9a = () => interopDefault(import('../pages/handcontrol.vue' /* webpackChunkName: "pages/handcontrol" */))
const _7da965ce = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _5f20f760 = () => interopDefault(import('../pages/orders.vue' /* webpackChunkName: "pages/orders" */))
const _224f384e = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _66558433 = () => interopDefault(import('../pages/scada.vue' /* webpackChunkName: "pages/scada" */))
const _2011511a = () => interopDefault(import('../pages/tasks.vue' /* webpackChunkName: "pages/tasks" */))
const _6dadb9f5 = () => interopDefault(import('../pages/c02/_id.vue' /* webpackChunkName: "pages/c02/_id" */))
const _a5b4a5ee = () => interopDefault(import('../pages/humidity/_id.vue' /* webpackChunkName: "pages/humidity/_id" */))
const _57dc69c4 = () => interopDefault(import('../pages/temperature/_id.vue' /* webpackChunkName: "pages/temperature/_id" */))
const _0c59d7cc = () => interopDefault(import('../pages/voc/_id.vue' /* webpackChunkName: "pages/voc/_id" */))
const _97fc7a92 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/climateandzone",
    component: _094dafae,
    name: "climateandzone"
  }, {
    path: "/handcontrol",
    component: _2de6ef9a,
    name: "handcontrol"
  }, {
    path: "/login",
    component: _7da965ce,
    name: "login"
  }, {
    path: "/orders",
    component: _5f20f760,
    name: "orders"
  }, {
    path: "/register",
    component: _224f384e,
    name: "register"
  }, {
    path: "/scada",
    component: _66558433,
    name: "scada"
  }, {
    path: "/tasks",
    component: _2011511a,
    name: "tasks"
  }, {
    path: "/c02/:id?",
    component: _6dadb9f5,
    name: "c02-id"
  }, {
    path: "/humidity/:id?",
    component: _a5b4a5ee,
    name: "humidity-id"
  }, {
    path: "/temperature/:id?",
    component: _57dc69c4,
    name: "temperature-id"
  }, {
    path: "/voc/:id?",
    component: _0c59d7cc,
    name: "voc-id"
  }, {
    path: "/",
    component: _97fc7a92,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
